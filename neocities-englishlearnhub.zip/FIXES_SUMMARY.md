Summary of automated fixes performed:

- Stripped console.* lines in sw.js
- Stripped console.* lines in js/achievements.js
- Stripped console.* lines in js/common.js
- Stripped console.* lines in js/daily.js
- Stripped console.* lines in js/exam.js
- Stripped console.* lines in js/flashcards_with_sentence_activity.js
- Stripped console.* lines in js/flip_cards.js
- Stripped console.* lines in js/index.js
- Stripped console.* lines in js/learning-path.js
- Stripped console.* lines in js/main.js
- Removed trailing commas in js/progress-charts.js
- Stripped console.* lines in js/progress-charts.js
- Stripped console.* lines in js/reading.js
- Stripped console.* lines in js/sentence-activity.js
- Stripped console.* lines in js/teaching.js
- Stripped console.* lines in js/user-profile.js
- Stripped console.* lines in js/word_games.js
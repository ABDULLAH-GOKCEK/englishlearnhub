{
  "animals": [
    {
      "word": "Cat",
      "image": "images/animals/cat.jpg",
      "difficulty": "easy",
      "category": "animals",
      "sentence": "The cat is sleeping on the sofa."
    }
  ],
  "foods": [
    {
      "word": "Apple",
      "image": "images/foods/apple.jpg",
      "difficulty": "easy",
      "category": "foods",
      "sentence": "I eat an apple every morning."
    }
  ],
  "sentences": [
    {
      "word": "How are you?",
      "translation": "Nasılsın?",
      "difficulty": "easy",
      "category": "sentences"
    }
  ]
}
